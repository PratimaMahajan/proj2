using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class BolleStorico : System.Web.UI.Page
{
	
  protected void Page_Load(object sender, EventArgs e)
  {
		if (!IsPostBack)
		{
			Session["txtRicerca"] = "";
			myParameter p;

			//	----------------------------------------------------------------------------------------------------
			//	Carico il DropDownList per Anno
			//	----------------------------------------------------------------------------------------------------
			Helper.FillDropDownList(cboAnno, DBHelper.GetSPDataSet("BOL_sp_EstraiAnniStoria"), "ceAnno", "ceAnno", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta un solo anno, lo si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboAnno.SelectedIndex == 0 && cboAnno.Items.Count == 2) cboAnno.SelectedIndex = 1;

			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			myParameters parSocieta = new myParameters();
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboSocieta.SelectedIndex == 0 && cboSocieta.Items.Count == 2) cboSocieta.SelectedIndex = 1;
			if (cboSocieta.Items.Count == 2)
			{ cboSocieta.SelectedIndex = 1; }
			else
			{ cboSocieta.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			myParameters parOrgUnit = new myParameters();
			if ((string)Session["flSocieta"] == "1" && cboSocieta.SelectedIndex == 0)
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			//{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString()); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono Admin posso gestire solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, ""); }
			else
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)Session["dsOrgUnit"]); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola Organization Unit, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboOrgUnit.SelectedIndex == 0 && cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
			if (cboOrgUnit.Items.Count == 2)
			{ cboOrgUnit.SelectedIndex = 1; }
			else
			{ cboOrgUnit.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Se sono SuperAdmin posso gestire tutte le societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{
				Panel_Societa.Visible = true;
			}
			else
			{
				lblSocieta.Text = cboSocieta.SelectedItem.ToString();
				Visua_Societa.Visible = true;
			}

			//	----------------------------------------------------------------------------------------------------
			//	Se sono Admin posso gestire tutte le OrgUnit della mia societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flOrgUnit"] == "1")
			{
				Panel_OrgUnit.Visible = true;
			}
			else
			{
				lblOrgUnit.Text = (string)Session["dsOrgUnit"];
				Visua_OrgUnit.Visible = true;
			}

			//	----------------------------------------------------------------------------------------------------
			//	Segnalo che � necessario selezionare un anno
			//	----------------------------------------------------------------------------------------------------
			Panel_Inizio.Visible = true;
		}
	}

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		if (Panel_Errore.Visible == false)
		{
			Panel_Inizio.Visible = false;
			Panel_Trovati.Visible = false;
			dgStorico.Visible = false;
			//
			//BindData();
			//if (IsPostBack || cboAnno.SelectedIndex > 0 || txtRicerca.Text != "")
			if (cboAnno.SelectedIndex > 0 || txtRicerca.Text != "")
			{
				//Panel_Inizio.Visible = false;
				BindData();
			}
			else
			{
				Panel_Inizio.Visible = true;
			}
		}
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella BOL_TB_bolle da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		Panel_None.Visible = false;
		Panel_Trovati.Visible = false;
		dgStorico.Visible = false;
		//
		if (txtRicerca.Text != (string)Session["txtRicerca"])
		{
			Session["txtRicerca"] = txtRicerca.Text;
			dgStorico.CurrentPageIndex = 0;
			Panel_Bolla.Visible = false;
		}
		DataSet ds;
		ds = GetStorico(cboAnno.SelectedValue.ToString(), cboSocieta.SelectedValue.ToString(), cboOrgUnit.SelectedValue.ToString(), txtRicerca.Text);
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgStorico.DataSource = ds;
			dgStorico.DataBind();
			dgStorico.Visible = true;
			//Panel_None.Visible = false;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
		}
		else
		{
			Panel_None.Visible = true;
			//dgStorico.Visible = false;
			//Panel_Trovati.Visible = false;
		}
		return;
	}


	public static DataSet GetStorico(string anno, string societa, string orgunit, string ricerca)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(anno))
		{
			p = new myParameter("@Anno", SqlDbType.NChar, 4, (string)anno);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(societa))
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, (string)societa);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(orgunit))
		{
			p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)orgunit);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(ricerca))
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, (string)ricerca);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiBolleSt", collP);
		return ds;
	}

	protected void dgStorico_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgStorico.SelectedIndex = e.Item.ItemIndex;
				Panel_Bolla.Visible = true;
				break;

			case "Collapse":
				dgStorico.SelectedIndex = -1;
				Panel_Bolla.Visible = false;
				break;
		}
	}

	protected void dgStorico_Dettaglio(object source, System.Web.UI.WebControls.DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;
			//
			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli bolla";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli bolla selezionata
				//	----------------------------------------------------------------------------------------------------
				Bolla VisBolla = new Bolla();
				VisBolla.GetBolla((dgStorico.DataKeys[e.Item.ItemIndex]).ToString(), "S");
				dettAnno.Text = VisBolla.ceAnno;
				dettProgr.Text = VisBolla.ceProgr;
				dettSocieta.Text = VisBolla.deSocieta;
				dettOrgUnit.Text = VisBolla.deOrgUnit;
				dettCDC.Text = VisBolla.deCDC;
				//
				dettUtGid.Text = VisBolla.ceUtente;
				dettUtNome.Text = VisBolla.deNome;
				if (!VisBolla.flUtente)
				{
					dettUtFornitore.Text = VisBolla.deFornitore;
					Panel_Fornitore.Visible = true;
					Panel_UtSocieta.Visible = false;
				}
				else
				{
					dettUtSocieta.Text = VisBolla.utSocieta;
					dettUtSede.Text = VisBolla.utSede;
					dettUtOrgUnit.Text = VisBolla.utOrgUnit;
					Panel_Fornitore.Visible = false;
					Panel_UtSocieta.Visible = true;
				}
				dettMotivo.Text = VisBolla.deMotivo;
				dettRiferimento.Text = VisBolla.deRiferimento;
				dettSpedizione.Text = VisBolla.ceSpedizione;
				dettDestinazione.Text = "";
				if (!string.IsNullOrEmpty(VisBolla.ceDestinazione))
				{ dettDestinazione.Text = VisBolla.ceDestinazione + "<br />"; }
				dettDestinazione.Text = dettDestinazione.Text + VisBolla.deDestinazione;
			}
		}
	}

 //	----------------------------------------------------------------------------------------------------
 //	Cambia selezione Anno emissione bolla
 //	----------------------------------------------------------------------------------------------------
 protected void cboAnno_SelectedIndexChanged(object sender, EventArgs e)
 {
	 Panel_Bolla.Visible = false;
	 //
	 dgStorico.CurrentPageIndex = 0;
	 dgStorico.SelectedIndex = -1;
 }

	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		myParameters parOrgUnit = new myParameters();
		myParameter p;
		p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, "");
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
		//	----------------------------------------------------------------------------------------------------
		//	Se risulta una sola Organization Unit, la si seleziona
		//	----------------------------------------------------------------------------------------------------
		if (cboOrgUnit.SelectedIndex == 0 && cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
		//
		dgStorico.CurrentPageIndex = 0;
		dgStorico.SelectedIndex = -1;
		Panel_Bolla.Visible = false;
	}

	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Organization Unit
	//	----------------------------------------------------------------------------------------------------
	protected void cboOrgUnit_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgStorico.CurrentPageIndex = 0;
		dgStorico.SelectedIndex = -1;
		Panel_Bolla.Visible = false;
	}

	protected void btnCerca_Click(object sender, ImageClickEventArgs e)
	{
		dgStorico.CurrentPageIndex = 0;
		dgStorico.SelectedIndex = -1;
		Panel_Bolla.Visible = false;
	}

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgStorico.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgStorico.CurrentPageIndex = 0;
		dgStorico.SelectedIndex = -1;
		Panel_Bolla.Visible = false;
	}

	public void dgStorico_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		dgStorico.CurrentPageIndex = e.NewPageIndex;
		dgStorico.SelectedIndex = -1;
		Panel_Bolla.Visible = false;
	}

}
