using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for FornitoreSoc
/// </summary>

public class FornitoreSoc
{
	private string _ceFornitore;
	private string _ceSocieta;

	public string ceFornitore
	{
		set { _ceFornitore = value; }
	}

	public string ceSocieta
	{
		set { _ceSocieta = value; }
	}

	public FornitoreSoc(string fornitore, string societa)
	{
		_ceFornitore = fornitore;
		_ceSocieta = societa;
	}

	public void Inserisci_Forn_Soc()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@Fornitore", SqlDbType.Int, 6, Convert.ToDouble(_ceFornitore));
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Societa", SqlDbType.VarChar, 16, _ceSocieta);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Data", SqlDbType.DateTime, 8, DateTime.Now);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_InsertFornSoc", collP);
	}

	public void Delete_Forn_Soc()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@Fornitore", SqlDbType.Int, 6, Convert.ToDouble(_ceFornitore));
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Societa", SqlDbType.VarChar, 16, _ceSocieta);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_DeleteFornSoc", collP);
	}
}
