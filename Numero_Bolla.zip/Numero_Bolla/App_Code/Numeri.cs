using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for NumeriMan
/// </summary>

public class Numeri
{
	public string _ceSocieta;
	public string _deSocieta;
	public string _ceAnno;
	public string _nmInizio;
	public string _nmFine;
	public string _nmNumero;

	public string ceSocieta
	{
		set { _ceSocieta = value; }
		get { return _ceSocieta; }
	}

	public string deSocieta
	{
		get { return _deSocieta; }
	}

	public string ceAnno
	{
		set { _ceAnno = value; }
		get { return _ceAnno; }
	}

	public string nmInizio
	{
		set { _nmInizio = value; }
		get { return _nmInizio; }
	}

	public string nmFine
	{
		set { _nmFine = value; }
		get { return _nmFine; }
	}

	public string nmNumero
	{
		get { return _nmNumero; }
	}


	//	----------------------------------------------------------------------------------------------------
	//	Definizione nuovo elemento numerazione bolle
	//	----------------------------------------------------------------------------------------------------
	public Numeri()
	{
		_ceSocieta = null;
		_ceAnno = null;
		_nmInizio = null;
		_nmFine = null;
		_nmNumero = null;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Estrazione dati numerazione bolla
	//	----------------------------------------------------------------------------------------------------
	public Numeri(string soc_anno)
	{
		myParameters collP = new myParameters();
		myParameter p;
		p = new myParameter("@SocAnno", SqlDbType.VarChar, 6, soc_anno);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_GetNumeri", collP);

		if ((dr != null) && dr.Read())
		{
			_ceSocieta = dr["ceSocieta"].ToString();
			_deSocieta = dr["deSocieta"].ToString();
			_ceAnno = dr["ceAnno"].ToString();
			_nmInizio = dr["nmInizio"].ToString();
			_nmFine = dr["nmFine"].ToString();
			_nmNumero = dr["nmNUmero"].ToString();
		}
		else
		{
			_ceAnno = "0";
		}
		dr.Close();
	}

	public void CercaNumeri(string societa, string anno)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (societa != null)
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, societa);
			collP.Add(p.CreateSQLParameter());
		}
		p = new myParameter("@Anno", SqlDbType.VarChar, 4, anno);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_CercaAnno", collP);
		if ((dr != null) && dr.Read())
		{
			_ceAnno = dr["ceAnno"].ToString();
		}
		else
		{
			_ceAnno = "0";
		}
		dr.Close();
	}


	//	----------------------------------------------------------------------------------------------------
	//	Inserimento nuovo elemento numerazione bolle
	//	----------------------------------------------------------------------------------------------------
	public void InserisciNumeri()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@Societa", SqlDbType.VarChar, 16, _ceSocieta);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Anno", SqlDbType.Char, 4, _ceAnno);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Inizio", SqlDbType.Char, 15, _nmInizio);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Fine", SqlDbType.Char, 15, _nmFine);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_InsertNumeri", collP);
	}
	

	//	----------------------------------------------------------------------------------------------------
	//	Aggiornamento ultimo numero di bolla
	//	----------------------------------------------------------------------------------------------------
	public void AggiornaNumero(string societa, string anno)
	{
		myParameters collP = new myParameters();
		myParameter p;

		p = new myParameter("@SocAnno", SqlDbType.Char, 6, societa + anno);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_GetNumeri", collP);

		if ((dr != null) && dr.Read())
		{
			_ceSocieta = dr["ceSocieta"].ToString();
			_deSocieta = dr["deSocieta"].ToString();
			_ceAnno = dr["ceAnno"].ToString();
			_nmInizio = dr["nmInizio"].ToString();
			_nmFine = dr["nmFine"].ToString();
			_nmNumero = dr["nmNUmero"].ToString();
		}
		else
		{
			_ceAnno = "0";
		}
		dr.Close();

		if (_ceAnno != "0")
		{
			if (_nmNumero == "0")
			{
				_nmNumero = _nmInizio;
			}
			else
			{
				_nmNumero = Convert.ToString ( Convert.ToDouble(_nmNumero.ToString()) + 1);
			}
			myParameters collNum = new myParameters();
			myParameter pN;
			pN = new myParameter("@Societa", SqlDbType.Char, 2, societa);
			collNum.Add(pN.CreateSQLParameter());
			pN = new myParameter("@Anno", SqlDbType.VarChar, 4, anno);
			collNum.Add(pN.CreateSQLParameter());
			pN = new myParameter("@Numero", SqlDbType.VarChar, 15, _nmNumero);
			collNum.Add(pN.CreateSQLParameter());
			DBHelper.ExecuteNonQuery("BOL_sp_UpdateNumero", collNum);
		}
	}

}
