﻿// JScript File
function ApriFinestra(Url,x,y,w,h)
{
    x=window.open(Url,'','left='+x+',top='+y+',width='+w+',height='+h+',toolbar=0,menubar=0,location=0,scrollbars=1,resizable=0');
    x.focus();
}

